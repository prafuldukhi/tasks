module.exports = {
    secretKey: 'your_secret_key', // Replace with your actual secret key
    mongoURI: 'mongodb://localhost:27017/productsDB' // Replace with your MongoDB URI
  };